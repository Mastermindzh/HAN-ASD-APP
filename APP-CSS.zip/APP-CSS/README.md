# APP-CSS

Implementation of a css dialect (ICSS) parser for school.

![alt text](http://i.imgur.com/AYAsoev.png "Screenshot of implementation")
