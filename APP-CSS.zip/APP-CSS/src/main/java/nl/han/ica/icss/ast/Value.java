package nl.han.ica.icss.ast;

public abstract class Value extends ASTNode {}
