package nl.han.ica.icss.ast;

public abstract class Literal extends Value {

}
